package arthmetic_calculator;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainCalcClass {

	public static void main(String[] args) {
		float a=0,b=0;
		int choice = 0;
        float result=0;
        /*scanner class object to read values*/
        Scanner buf=new Scanner(System.in); 
         
        while(true) {
        	
        	//Listing various operations
        	System.out.print("\n1: Addition.\n2: Subtraction.");
            System.out.print("\n3: Multiplication.\n4: Divide.");
            System.out.print("\n5: Remainder.\n6: Exit.");
             
            //Getting the choice of operation
            System.out.print("\nEnter your choice: ");
            try {
            	choice = Integer.parseInt(buf.nextLine());
            }catch(Exception e) {
            	System.out.println("Please enter a valid choice");
            	continue;
            }
            
            //Checking if choice is as expected
            if(choice > 6 || choice < 1) {
            	System.out.println("Please enter a valid choice");
            	continue;
            }
            
            //Condition for exiting the loop
        	if (choice == 6) {
        		System.out.println("Calculator closed... 🙂");
        		break;
        	}
        	
        	//getting first operands
        	System.out.print("Enter first number: ");
        	try {
        		a= Float.parseFloat(buf.nextLine());
            }catch(Exception e) {
            	System.out.println("Please enter a valid value");
            	continue;
            }
        	
        	//getting second operands
            System.out.print("Enter second number: ");
            try {
            	b= Float.parseFloat(buf.nextLine());
            }catch(Exception e) {
            	System.out.println("Please enter a valid value");
            	continue;
            }
            
            //performing arithmetic operations
        	switch(choice)
            {
                case 1:
                    result=(a+b); break;
                case 2:
                    result=(a-b); break;
                case 3:
                    result=(a*b); break;
                case 4:
                    result=(float)((float)a/(float)b); break;
                case 5:
                    result=(a%b); break;
                default:
                    System.out.println("An Invalid Choice!!!\n");
            }
        	
        	//displaying result
        	System.out.println("----------------------------------");
            System.out.println(String.format("The result is %.1f",result));
            System.out.println("----------------------------------");
        }
        

	}

}
