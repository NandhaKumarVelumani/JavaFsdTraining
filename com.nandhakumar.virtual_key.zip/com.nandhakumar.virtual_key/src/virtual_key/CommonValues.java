package virtual_key;

public interface CommonValues {
	String PATH = "src//virtual_key//LockerMe_Files";
}
