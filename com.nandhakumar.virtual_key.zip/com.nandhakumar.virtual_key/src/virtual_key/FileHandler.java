package virtual_key;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class FileHandler implements CommonValues{
	
	public static File[] filesObjList;
	
	public String[] createFilesList() {
		File folder = new File(PATH);
		filesObjList = folder.listFiles();
		String filesName[] = new String[filesObjList.length];
		
		int idx = 0;
		for(File x: filesObjList) {
			filesName[idx] = x.getName();
			idx += 1;
		}
		
		return filesName;
	}
	
	public void displayFiles() {
		
		for(String x: this.createFilesList()) {
			System.out.println(x);
		}
	}

	public void createFile(String fileName) throws IOException {
		Files.createFile(Paths.get(PATH+"//"+fileName));
	}

	public boolean deleteFile(String fileName, String flag) throws IOException {
		if(flag == "check")
			return Files.exists(Paths.get(PATH+"//"+fileName));
		return Files.deleteIfExists(Paths.get(PATH+"//"+fileName));
	}

	public int searchFile(String fileName) {
		return Arrays.binarySearch(createFilesList(), fileName);
	}
	
}
