package virtual_key;

import java.io.IOException;
import java.util.Scanner;

public class VirtualKeyMain implements CommonValues{
	
	public static void displayWelcomeMsg() {
		System.out.println("Welcome to LockerMe.com");
		System.out.println("This was developed by Nandhakumar Velumani");
	}
	
	

	public static void main(String[] args) {
		
		int option;
		String fileName;
		
		//creation of FileHandler object
		FileHandler fh = new FileHandler();
		
		displayWelcomeMsg();
		System.out.println('\n');
		
		//Creating Scanner object
		Scanner sc = new Scanner(System.in);
		
		loop: while(true) {
			
			//displaying the menu
			System.out.println("The options are:\n1. Display the available files\n2. Add a file\n3. Delete a file\n4. Search a file\n5. Close application");
			
			//getting user options
			option = sc.nextInt();
			switch(option) {
				case 1:
					System.out.println("The available files are: ");
					fh.displayFiles();
					break;
				case 2:
					System.out.println("Enter the file name with extension: ");
					fileName = sc.next().toLowerCase();
				try {
					fh.createFile(fileName);
					System.out.println("File successfully created 🙂");
				} catch (IOException e) {
					System.out.println("File creation failed");
					e.printStackTrace();
				}
					break;
				case 3:
					System.out.println("Enter the file name with extension to be deleted: ");
					fileName = sc.next().toLowerCase();
				try {
					if(fh.deleteFile(fileName, "check")) {
						System.out.println("Confirm delete : Enter y/any key: ");
						String choice = sc.next().toLowerCase();
						if(choice.equals("y")) {
							fh.deleteFile(fileName, "delete");
							System.out.println("File deleted successfully 😊");
						}
						else
							System.out.println("File deletion cancelled 😊");
					}
					else {
						System.out.println("File not found");
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
					break;
				case 4:
					System.out.println("Enter the file name with extension to be searched: ");
					fileName = sc.next().toLowerCase();
					if(fh.searchFile(fileName)!= -1)
						System.out.println("The file is found 🙂");
					else
						System.out.println("The file is not found 🥲");
					break;
				case 5:
					System.out.println("Thanks you for choosing LockerMe 😍");
					break loop;
				default:
					System.out.println("You entered wrong option");
			}
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
