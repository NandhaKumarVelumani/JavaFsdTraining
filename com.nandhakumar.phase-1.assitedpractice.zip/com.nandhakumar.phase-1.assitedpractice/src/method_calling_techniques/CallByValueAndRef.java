package method_calling_techniques;

public class CallByValueAndRef {
	
	int data = 100;
	
	static void callByValueFunc(int a) {
		a = a + 10;
	}
	
	static void callByRefFunc(CallByValueAndRef objparam) {
		objparam.data = 99;
	}

	public static void main(String[] args) {
		int a = 12;
		
		callByValueFunc(a);
		//the value of a is unchanged
		System.out.println("The value of a is: "+a);
		
		CallByValueAndRef obj = new CallByValueAndRef();
		
		callByRefFunc(obj);
		//the value of obj.data is changed because they share the same reference
		System.out.println("The value of a is: "+obj.data);
		
	}

}
