package types_of_constructors;

public class MainClass {

	public static void main(String[] args) {
		int a = 10;
		int b =20;
		
//		ConstructorClass cc = new ConstructorClass();
		ConstructorClass cc1 = new ConstructorClass(a, b);
		
		//getting the value of dummy whose value is assigned by default constructor invoked by line 9
//		System.out.println(cc.dummy);
	}

}
