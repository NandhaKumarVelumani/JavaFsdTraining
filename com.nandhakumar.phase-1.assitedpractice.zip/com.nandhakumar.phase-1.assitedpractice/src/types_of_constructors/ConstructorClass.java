package types_of_constructors;

public class ConstructorClass {
	public int dummy;
	
	//default constructor acted implicitly and assign 0 to dummy
	public int getDummy() {
		return dummy;
	}
	
	//non-parameterized Constructor
	ConstructorClass() {
		System.out.println("I am from non-parameterized Constructor");
	}
	
	//parameterized Constructor
	ConstructorClass(int a, int b){
		System.out.println("I am from parameterized Constructor");
		System.out.println("You have sent two values: "+a+", "+b);
	}
}
