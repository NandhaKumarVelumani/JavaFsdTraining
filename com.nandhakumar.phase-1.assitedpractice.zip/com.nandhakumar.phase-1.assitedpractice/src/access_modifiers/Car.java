package access_modifiers;

public class Car {
	
	//Static variable
	public static String company = "Tata";
		
	//Private variables	
	private int carUnlockPassword;
	
	//public variables
	public int AccelerateSpeedTo;
	public String modelName;
	
	Car(int carUnlockPassword, int AccelerateSpeedTo, String modelName){
		this.carUnlockPassword = carUnlockPassword;
		this.AccelerateSpeedTo = AccelerateSpeedTo;
		this.modelName = modelName;
		
		autheticateDriver(this.carUnlockPassword);
	}
	
	public void getSpeed() {
		System.out.println(this.AccelerateSpeedTo);
	}
	
	public void getModelName() {
		System.out.println("Car is running at "+this.modelName+"km/hr");
	}
	
	private void autheticateDriver(int carUnlockPassword) {
		if (carUnlockPassword == this.carUnlockPassword) {
			System.out.println("Car driver authenticated \nCar started");
		}
	}
}
