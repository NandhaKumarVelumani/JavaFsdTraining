package access_modifiers;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		
		//Scanner
		Scanner sc = new Scanner(System.in);
		
		//instantiating car object
		System.out.print("Enter the password to start the car: ");
		int password = sc.nextInt();
		System.out.print("How much you want to accelerate: ");
		int speed = sc.nextInt();
		Car car1 = new Car(password, speed, "Nexon");
		
		car1.getSpeed();
		car1.getModelName();
		
		//accessing carUnlockPassword cannot be accessed because of private access specifier
		//below code will throw error
//		car1.carUnlockPassword;
	}
}
