package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		
		//Correct user credentials
		String CorrectUserName = "nandha";
		String CorrectPassword = "1234";
		
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		
		RequestDispatcher rd;
		if(userName.equals(CorrectUserName) && password.equals(CorrectPassword)) {
			HttpSession session = request.getSession();
			session.setAttribute("userName", userName);
			
			PrintWriter out = response.getWriter();
			out.print("<h1>Welcome "+ session.getAttribute("userName")+"</h1>" + " &nbsp "
					+ "&nbsp &nbsp<a style='color: red; text-decoration: none' href='LogoutServlet'>Logout</a>");
			rd = request.getRequestDispatcher("dashboard.html");
			rd.include(request, response);
		}else {
			PrintWriter out = response.getWriter();
			out.print("<span style='color: red'>Invalid credentials</p></span>");
			rd = request.getRequestDispatcher("loginPage.html");
			rd.include(request, response);
		}
	}

}
