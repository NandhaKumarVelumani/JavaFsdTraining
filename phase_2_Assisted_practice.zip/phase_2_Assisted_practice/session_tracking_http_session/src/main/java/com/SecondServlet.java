package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import data_transfer_objects.User;

/**
 * Servlet implementation class SecondServlet
 */
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int age = Integer.parseInt(request.getParameter("age"));
		Long contact = Long.parseLong(request.getParameter("contact"));
		
		HttpSession session = request.getSession(false); //calls a existing session
		
		if(session != null) {
			
			User user = (User) session.getAttribute("user");
			
			user.setAge(age);
			user.setContact(contact);
			
			//creating a name and value for session
			session.setAttribute("user", user);
			
			//redirecting to next page
			response.sendRedirect("ThirdServlet");
		}
	}

}
